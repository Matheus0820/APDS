package aula5;

public class Principal {
	
    public static void main(String[] args) {
        ListFilesRecursively obiJudge = new ListFilesRecursively();
        String startDir = ("C:\\Users\\Aluno\\Documents\\APDS - CAIO\\aula05\\files");
        obiJudge.listDirectoryTree(startDir);
    }
}	