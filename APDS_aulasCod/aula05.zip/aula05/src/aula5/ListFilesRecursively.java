// Percorre �rvore de diret�rios de gabarito de quest�es OBI, com estrutura de testes testX, inY1, inY2, outY1, outY2
// Autor: Josenalde Oliveira out22

package aula5;

import java.io.File;

public class ListFilesRecursively {
	
	public void listDirectoryTree(String startDir) {
		File dir = new File(startDir);
		File[] files = dir.listFiles();
		
		ManageIO extractValues = new ManageIO();

		if (files != null && files.length > 0) {
			for (File file : files) {
				// Verifica se arquivo atual � pasta/diret�rio
				if (file.isDirectory()) {
					// Se for entra recursivamente para listar arquivos
					listDirectoryTree(file.getAbsolutePath());
				} else {
					// We can use .length() to get the file size
					System.out.println(file.getName() + " (size in bytes: " + file.length()+")");
					System.out.println(file.getAbsolutePath());
					extractValues.ReadFile(file.getAbsolutePath());
				}
			}
		}
	}
}